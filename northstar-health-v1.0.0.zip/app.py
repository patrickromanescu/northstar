import time
import socket
import statistics
from datetime import datetime

import pandas as pd
import plotly.graph_objects as go
import requests
import streamlit as st


st.set_page_config(
    page_title="NorthStar Health",
    page_icon="🛰️",
    layout="wide",
    initial_sidebar_state="collapsed",
)


st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

html, body, [class*="css"] {
    font-family: 'Inter', sans-serif;
}

.stApp {
    background:
        radial-gradient(circle at 78% 8%, rgba(37, 99, 235, 0.18), transparent 32%),
        radial-gradient(circle at 12% 92%, rgba(16, 185, 129, 0.08), transparent 30%),
        #03040a;
    color: #f8fafc;
}

.block-container {
    max-width: 1500px;
    padding-top: 2rem;
    padding-bottom: 3rem;
}

[data-testid="stHeader"] {
    background: transparent;
}

h1, h2, h3 {
    letter-spacing: -0.045em;
}

.ns-hero {
    padding: 28px 0 22px 0;
    border-bottom: 1px solid rgba(255,255,255,0.10);
    margin-bottom: 26px;
}

.ns-badge {
    display: inline-flex;
    align-items: center;
    gap: 9px;
    border: 1px solid rgba(34,197,94,0.28);
    background: rgba(34,197,94,0.08);
    color: #86efac;
    border-radius: 999px;
    padding: 7px 11px;
    font-size: 11px;
    font-weight: 700;
    margin-bottom: 16px;
}

.ns-dot {
    width: 7px;
    height: 7px;
    background: #22c55e;
    border-radius: 999px;
    box-shadow: 0 0 18px rgba(34,197,94,0.95);
}

.ns-title {
    font-size: 48px;
    line-height: 1.02;
    font-weight: 820;
    max-width: 760px;
    margin: 0;
}

.ns-subtitle {
    color: #cbd5e1;
    max-width: 760px;
    line-height: 1.7;
    font-size: 15.5px;
    margin-top: 16px;
}

.ns-panel {
    border: 1px solid rgba(255,255,255,0.10);
    background: rgba(255,255,255,0.035);
    border-radius: 18px;
    padding: 20px;
}

.ns-panel-compact {
    border: 1px solid rgba(255,255,255,0.09);
    background: rgba(255,255,255,0.028);
    border-radius: 16px;
    padding: 16px;
}

.ns-kicker {
    text-transform: uppercase;
    letter-spacing: 0.24em;
    font-size: 10px;
    color: #93c5fd;
    font-weight: 800;
}

.ns-muted {
    color: #94a3b8;
    font-size: 13px;
    line-height: 1.6;
}

.ns-score {
    font-size: 72px;
    line-height: 0.9;
    letter-spacing: -0.08em;
    font-weight: 850;
    margin: 14px 0 8px 0;
}

.ns-good { color: #22c55e; font-weight: 800; }
.ns-warn { color: #f59e0b; font-weight: 800; }
.ns-bad { color: #ef4444; font-weight: 800; }

.ns-gridline {
    border-top: 1px solid rgba(255,255,255,0.10);
    padding-top: 22px;
    margin-top: 26px;
}

.stButton > button {
    background: #f8fafc !important;
    color: #020617 !important;
    border: 0 !important;
    border-radius: 12px !important;
    height: 2.8rem !important;
    font-weight: 800 !important;
}

.stButton > button:hover {
    background: #dbeafe !important;
}

.stDownloadButton > button {
    background: rgba(255,255,255,0.055) !important;
    color: white !important;
    border: 1px solid rgba(255,255,255,0.12) !important;
    border-radius: 12px !important;
    height: 2.75rem !important;
    font-weight: 700 !important;
}

div[data-baseweb="select"] > div {
    background-color: rgba(255,255,255,0.055);
    border-radius: 12px;
    border: 1px solid rgba(255,255,255,0.10);
}

[data-testid="stMetric"] {
    border: 1px solid rgba(255,255,255,0.08);
    background: rgba(255,255,255,0.025);
    padding: 14px;
    border-radius: 14px;
}

[data-testid="stMetricValue"] {
    font-size: 24px !important;
    font-weight: 780 !important;
}

[data-testid="stMetricLabel"] {
    color: #94a3b8 !important;
    font-size: 12px !important;
}

hr {
    border-color: rgba(255,255,255,0.10) !important;
}

.footer-note {
    color: #64748b;
    font-size: 12px;
    line-height: 1.7;
}
</style>
""", unsafe_allow_html=True)


def tcp_latency(host="1.1.1.1", port=443, timeout=2):
    start = time.time()
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return round((time.time() - start) * 1000, 2)
    except Exception:
        return None


def run_latency_tests(samples=10):
    latencies = []
    failed = 0

    for _ in range(samples):
        value = tcp_latency()
        if value is None:
            failed += 1
        else:
            latencies.append(value)
        time.sleep(0.06)

    if not latencies:
        return None, None, 100.0

    avg_latency = round(statistics.mean(latencies), 2)
    jitter = round(statistics.stdev(latencies), 2) if len(latencies) > 1 else 0.0
    packet_loss = round((failed / samples) * 100, 2)

    return avg_latency, jitter, packet_loss


def download_speed(bytes_size=6_000_000):
    url = f"https://speed.cloudflare.com/__down?bytes={bytes_size}"
    start = time.time()

    try:
        with requests.get(url, timeout=14, stream=True) as response:
            response.raise_for_status()
            total = 0
            for chunk in response.iter_content(chunk_size=64_000):
                if chunk:
                    total += len(chunk)

        elapsed = max(time.time() - start, 0.001)
        return round(((total * 8) / 1_000_000) / elapsed, 2)
    except Exception:
        return None


def upload_speed(bytes_size=1_250_000):
    url = "https://speed.cloudflare.com/__up"
    payload = b"x" * bytes_size
    start = time.time()

    try:
        response = requests.post(url, data=payload, timeout=14)
        response.raise_for_status()
        elapsed = max(time.time() - start, 0.001)
        return round(((bytes_size * 8) / 1_000_000) / elapsed, 2)
    except Exception:
        return None


def get_ip_context():
    try:
        response = requests.get("https://ipapi.co/json/", timeout=7)
        if response.status_code != 200:
            return {}
        data = response.json()
        return {
            "org": data.get("org"),
            "city": data.get("city"),
            "region": data.get("region"),
            "country": data.get("country_name"),
        }
    except Exception:
        return {}


def get_cloudflare_trace():
    try:
        response = requests.get("https://www.cloudflare.com/cdn-cgi/trace", timeout=7)
        parsed = {}
        for line in response.text.splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                parsed[key] = value
        return {"edge": parsed.get("colo")}
    except Exception:
        return {}


def calculate_score(latency, jitter, download, upload, packet_loss):
    score = 100

    if latency is None:
        score -= 28
    elif latency > 220:
        score -= 28
    elif latency > 140:
        score -= 18
    elif latency > 80:
        score -= 8

    if jitter is None:
        score -= 12
    elif jitter > 90:
        score -= 12
    elif jitter > 45:
        score -= 7

    if download is None:
        score -= 16
    elif download < 3:
        score -= 16
    elif download < 8:
        score -= 10
    elif download < 15:
        score -= 4

    if upload is None:
        score -= 20
    elif upload < 1.5:
        score -= 20
    elif upload < 4:
        score -= 12
    elif upload < 8:
        score -= 5

    if packet_loss > 5:
        score -= 24
    elif packet_loss > 2:
        score -= 13
    elif packet_loss > 1:
        score -= 6

    return max(0, min(100, int(score)))


def recommendation(score):
    if score >= 85:
        return "Proceed with full video consultation", "ns-good"
    if score >= 70:
        return "Proceed with standard video consultation", "ns-good"
    if score >= 55:
        return "Use low-bandwidth video and prepare phone backup", "ns-warn"
    if score >= 35:
        return "Use phone backup or move to alternate site", "ns-warn"
    return "Activate backup care pathway", "ns-bad"


def clinical_threshold(mode):
    return {
        "Primary care video visit": 70,
        "Mental health consultation": 75,
        "Specialist review": 80,
        "Emergency virtual assessment": 85,
        "Low-bandwidth follow-up": 55,
    }.get(mode, 70)


if "history" not in st.session_state:
    st.session_state.history = []


st.markdown("""
<div class="ns-hero">
    <div class="ns-badge">
        <span class="ns-dot"></span>
        Starlink-compatible telehealth readiness
    </div>
    <h1 class="ns-title">Know if virtual care will hold before the visit starts.</h1>
    <p class="ns-subtitle">
        NorthStar Health checks satellite-supported connectivity, latency, jitter,
        packet loss, and bandwidth against clinical telehealth requirements, giving
        rural care teams a simple readiness decision before patients lose time.
    </p>
</div>
""", unsafe_allow_html=True)


left, right = st.columns([0.58, 0.42], gap="large")

with left:
    st.markdown("### Assessment")

    clinical_mode = st.selectbox(
        "Care scenario",
        [
            "Primary care video visit",
            "Mental health consultation",
            "Specialist review",
            "Emergency virtual assessment",
            "Low-bandwidth follow-up",
        ],
    )

    samples = st.slider("Sampling intensity", 6, 24, 12)

    run_test = st.button("Run readiness assessment", type="primary", use_container_width=True)

with right:
    st.markdown("""
    <div class="ns-panel">
        <div class="ns-kicker">Satellite layer</div>
        <h3 style="margin: 12px 0 8px 0;">Starlink-Compatible</h3>
        <p class="ns-muted" style="margin-bottom:0;">
            Monitors conditions relevant to satellite-supported virtual care:
            latency, packet loss, jitter, uplink capacity, and network routing.
        </p>
    </div>
    """, unsafe_allow_html=True)


if run_test:
    with st.spinner("Running diagnostics..."):
        latency, jitter, packet_loss = run_latency_tests(samples=samples)
        down = download_speed()
        up = upload_speed()
        ip_context = get_ip_context()
        cf_trace = get_cloudflare_trace()

        score = calculate_score(latency, jitter, down, up, packet_loss)
        rec, status_class = recommendation(score)

        st.session_state.history.append({
            "timestamp": datetime.now().strftime("%H:%M:%S"),
            "clinical_mode": clinical_mode,
            "score": score,
            "latency_ms": latency,
            "jitter_ms": jitter,
            "download_mbps": down,
            "upload_mbps": up,
            "packet_loss_percent": packet_loss,
            "recommendation": rec,
            "network_org": ip_context.get("org"),
            "city": ip_context.get("city"),
            "region": ip_context.get("region"),
            "country": ip_context.get("country"),
            "cloudflare_edge": cf_trace.get("edge"),
        })


if st.session_state.history:
    latest = st.session_state.history[-1]
    rec, status_class = recommendation(latest["score"])
    threshold = clinical_threshold(latest["clinical_mode"])

    st.markdown('<div class="ns-gridline"></div>', unsafe_allow_html=True)

    score_col, metric_col = st.columns([0.36, 0.64], gap="large")

    with score_col:
        st.markdown(f"""
        <div class="ns-panel">
            <div class="ns-kicker">Readiness index</div>
            <div class="ns-score">{latest["score"]}</div>
            <p class="ns-muted">Clinical threshold: {threshold}/100</p>
            <p class="{status_class}" style="font-size:17px;">● {rec}</p>
        </div>
        """, unsafe_allow_html=True)

    with metric_col:
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Latency", f"{latest['latency_ms']} ms" if latest["latency_ms"] else "—")
        m2.metric("Jitter", f"{latest['jitter_ms']} ms" if latest["jitter_ms"] else "—")
        m3.metric("Download", f"{latest['download_mbps']} Mbps" if latest["download_mbps"] else "—")
        m4.metric("Upload", f"{latest['upload_mbps']} Mbps" if latest["upload_mbps"] else "—")

        st.markdown(f"""
        <div class="ns-panel-compact" style="margin-top:14px;">
            <div class="ns-kicker">Recommendation</div>
            <p style="margin:10px 0 0 0; color:#cbd5e1;">
                Scenario: <b>{latest["clinical_mode"]}</b>. 
                Packet loss: <b>{latest["packet_loss_percent"]}%</b>.
                Recommendation generated using clinical readiness thresholds.
            </p>
        </div>
        """, unsafe_allow_html=True)

    df = pd.DataFrame(st.session_state.history)

    st.markdown("### Readiness trend")

    fig = go.Figure()
    fig.add_trace(go.Scatter(
        x=df["timestamp"],
        y=df["score"],
        mode="lines+markers",
        name="Readiness",
        line=dict(width=2),
        marker=dict(size=7),
    ))

    fig.add_hline(
        y=threshold,
        line_dash="dash",
        annotation_text="clinical threshold",
        annotation_position="top right",
    )

    fig.update_layout(
        yaxis=dict(range=[0, 100], title=None),
        xaxis=dict(title=None),
        template="plotly_dark",
        height=300,
        margin=dict(l=10, r=10, t=15, b=10),
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(255,255,255,0.02)",
        font=dict(color="#e5e7eb"),
        showlegend=False,
    )

    st.plotly_chart(fig, use_container_width=True)

    st.markdown("### Network")

    n1, n2, n3 = st.columns(3)

    n1.markdown(f"""
    <div class="ns-panel-compact">
        <div class="ns-kicker">Network</div>
        <p style="margin:10px 0 0 0;">{latest.get("network_org") or "Detected"}</p>
    </div>
    """, unsafe_allow_html=True)

    n2.markdown(f"""
    <div class="ns-panel-compact">
        <div class="ns-kicker">Routing</div>
        <p style="margin:10px 0 0 0;">{latest.get("city") or "Unknown"}, {latest.get("region") or ""}</p>
    </div>
    """, unsafe_allow_html=True)

    n3.markdown(f"""
    <div class="ns-panel-compact">
        <div class="ns-kicker">Edge</div>
        <p style="margin:10px 0 0 0;">{latest.get("cloudflare_edge") or "Detected"}</p>
    </div>
    """, unsafe_allow_html=True)

    st.write("")

    st.download_button(
        "Download readiness report",
        data=df.to_csv(index=False),
        file_name="northstar_readiness_report.csv",
        mime="text/csv",
        use_container_width=True,
    )

else:
    st.markdown("""
    <div class="ns-panel">
        <div class="ns-kicker">Awaiting assessment</div>
        <p class="ns-muted" style="margin-top:10px;">
            Run an assessment to generate a telehealth readiness index, clinical recommendation,
            and network intelligence summary.
        </p>
    </div>
    """, unsafe_allow_html=True)


st.markdown("""
<p class="footer-note">
NorthStar Health does not collect patient information. Diagnostics are intended for operational telehealth readiness and do not replace clinical judgment.
</p>
""", unsafe_allow_html=True)